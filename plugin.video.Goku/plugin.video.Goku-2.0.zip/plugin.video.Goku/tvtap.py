# -*- coding: utf-8 -*-

from libs.tools import *

def mainmenu(item):
    itemlist = list()

    itemlist.append(item.clone(
        label='Deportes',
        action='Deportes',
        icon=os.path.join(image_path, 'TV_Tap_Deportes.jpg'),
        plot='Enlaces de eventos recopilados de internet, no emito ningun canal.'
    ))

    itemlist.append(item.clone(
        label='Documentales',
        action='Documentales',
        icon=os.path.join(image_path, 'TV_Tap_Documentales.jpg'),
        plot='Muestra la Agenda oficial de Arenavision.'
    ))

    itemlist.append(item.clone(
        label='Musica',
        action='Musica',
        icon=os.path.join(image_path, 'TV_Tap_Musica.jpg'),
        plot='Muestra la Agenda oficial de Arenavision.'
    ))

    itemlist.append(item.clone(
        label='Peliculas',
        action='Peliculas',
        icon=os.path.join(image_path, 'TV_Tap_Pelis_Series.jpg'),
        plot='Muestra la Agenda oficial de Arenavision.'
    ))

    itemlist.append(item.clone(
        label='Series',
        action='Series',
        icon=os.path.join(image_path, 'TV_Tap_Pelis_Series.jpg'),
        plot='Muestra la Agenda oficial de Arenavision.'
    ))

    return itemlist


def Deportes(item):
    itemlist = list()
    try:
        url = 'plugin://script.module.TvTap/list_channels/5'
        command = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s","media":"video","properties":["thumbnail"]}, "id":1}' % url
        data = load_json(xbmc.executeJSONRPC(command))
        canales = data['result']['files']

        if get_setting('tap_sort'):
            canales.sort(key=lambda e: e['label'])

        for i in canales:
            if i['filetype'] == 'file':
                pais, name = i['label'].split(' - ')
                itemlist.append(item.clone(
                    label=name + (" (%s)" % pais if pais != 'OTH' else ''),
                    url=i['file'],
                    isPlayable=True,
                    icon= i['thumbnail'],
                    action='play'
                ))

    except:
        xbmcgui.Dialog().ok('Goku',
                            'Ups!  Parece que en estos momentos no hay eventos programados.',
                            'Intentelo mas tarde, por favor.')

    return itemlist

def Documentales(item):
    itemlist = list()
    try:
        url = 'plugin://script.module.TvTap/list_channels/6'
        command = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s","media":"video","properties":["thumbnail"]}, "id":1}' % url
        data = load_json(xbmc.executeJSONRPC(command))
        canales = data['result']['files']

        if get_setting('tap_sort'):
            canales.sort(key=lambda e: e['label'])

        for i in canales:
            if i['filetype'] == 'file':
                pais, name = i['label'].split(' - ')
                itemlist.append(item.clone(
                    label=name + (" (%s)" % pais if pais != 'OTH' else ''),
                    url=i['file'],
                    isPlayable=True,
                    icon= i['thumbnail'],
                    action='play'
                ))

    except:
        xbmcgui.Dialog().ok('Goku',
                            'Ups!  Parece que en estos momentos no hay eventos programados.',
                            'Intentelo mas tarde, por favor.')

    return itemlist

def Musica(item):
    itemlist = list()
    try:
        url = 'plugin://script.module.TvTap/list_channels/3'
        command = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s","media":"video","properties":["thumbnail"]}, "id":1}' % url
        data = load_json(xbmc.executeJSONRPC(command))
        canales = data['result']['files']

        if get_setting('tap_sort'):
            canales.sort(key=lambda e: e['label'])

        for i in canales:
            if i['filetype'] == 'file':
                pais, name = i['label'].split(' - ')
                itemlist.append(item.clone(
                    label=name + (" (%s)" % pais if pais != 'OTH' else ''),
                    url=i['file'],
                    isPlayable=True,
                    icon= i['thumbnail'],
                    action='play'
                ))

    except:
        xbmcgui.Dialog().ok('Goku',
                            'Ups!  Parece que en estos momentos no hay eventos programados.',
                            'Intentelo mas tarde, por favor.')

    return itemlist

def Peliculas(item):
    itemlist = list()
    try:
        url = 'plugin://script.module.TvTap/list_channels/2'
        command = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s","media":"video","properties":["thumbnail"]}, "id":1}' % url
        data = load_json(xbmc.executeJSONRPC(command))
        canales = data['result']['files']

        if get_setting('tap_sort'):
            canales.sort(key=lambda e: e['label'])

        for i in canales:
            if i['filetype'] == 'file':
                pais, name = i['label'].split(' - ')
                itemlist.append(item.clone(
                    label=name + (" (%s)" % pais if pais != 'OTH' else ''),
                    url=i['file'],
                    isPlayable=True,
                    icon= i['thumbnail'],
                    action='play'
                ))

    except:
        xbmcgui.Dialog().ok('Goku',
                            'Ups!  Parece que en estos momentos no hay eventos programados.',
                            'Intentelo mas tarde, por favor.')

    return itemlist

def Series(item):
    itemlist = list()
    try:
        url = 'plugin://script.module.TvTap/list_channels/1'
        command = '{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s","media":"video","properties":["thumbnail"]}, "id":1}' % url
        data = load_json(xbmc.executeJSONRPC(command))
        canales = data['result']['files']

        if get_setting('tap_sort'):
            canales.sort(key=lambda e: e['label'])

        for i in canales:
            if i['filetype'] == 'file':
                pais, name = i['label'].split(' - ')
                itemlist.append(item.clone(
                    label=name + (" (%s)" % pais if pais != 'OTH' else ''),
                    url=i['file'],
                    isPlayable=True,
                    icon= i['thumbnail'],
                    action='play'
                ))

    except:
        xbmcgui.Dialog().ok('Goku',
                            'Ups!  Parece que en estos momentos no hay eventos programados.',
                            'Intentelo mas tarde, por favor.')

    return itemlist
